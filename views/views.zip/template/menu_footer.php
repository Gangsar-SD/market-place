<footer class=" sticky-footer text-muted pt-3 bg-dark">
    <div class="container">

        <p> &copy; Gangsar Salatsa Dewantara </p>
        <p>Contact me @ <strong>Gangsartop@gmail.com</strong> or read Via Whatsapp @ <strong>0812-6192-3219</strong> </p>
        <p><strong>Credits to All creator of all assets</strong>in this website</p>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="<?= base_url('assets/') ?>js/vendor/jquery.slim.min.js"><\/script>')
</script>
</body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="<?= base_url('assets/') ?>js/vendor/jquery.slim.min.js"><\/script>')
</script>
<script src="<?= base_url('assets/') ?>dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
<script src="<?= base_url('assets/js/src/') ?>zoomsl.js"></script>
<script src="<?= base_url('assets/js/src/') ?>script.js"></script>


</html>