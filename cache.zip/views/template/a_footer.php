<script src="<?= base_url('assets/') ?>dist/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/') ?>dist/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/') ?>dist/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>